function t(t,e){switch(arguments.length){case 0:break;case 1:this.range(t);break;default:this.range(e).domain(t)}return this}export{t};
//# sourceMappingURL=init-BSHa7IJ-.js.map